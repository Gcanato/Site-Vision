<?php
// O remetente deve ser um e-mail do seu domínio conforme determina a RFC 822.
// O return-path deve ser ser o mesmo e-mail do remetente.
$headers = "MIME-Version: 1.1\r\n";
$headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
$headers .= "From: canatogui@uni9.edu.br\r\n"; // remetente
$headers .= "Return-Path: canatogui@uni9.edu.br\r\n"; // return-path

$nome = $_POST['nome'];
$fone = $_POST['fone'];
$email = $_POST['email'];
$msg = $_POST['msg'];

$texto = 'Nome: '.$nome.' | e-mail: '.$email.' | Telefone: '.$fone.' | Mensagem: '.$msg;

$envio = mail("canatogui@uni9.edu.br", "Contato do site", $texto, $headers, "-r" $email);

if($envio)
 echo "
 	<script>
		alert('Mensagem enviada com sucesso!');
		window.location.href='../index.html';
	</script>
 ";
else
 echo "
 	<script>
		alert('Erro ao enviar tente novamente mais tarde'.);
		window.location.href='../index.html';
	</script>
 ";
?>